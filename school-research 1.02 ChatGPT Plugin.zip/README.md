# school-research 1.02 — ChatGPT Work Plugin

本包包含一个 Skill。13 个运行文件与 school-research 1.02 发布版逐字节一致。

## 导入与测试

1. 打开 ChatGPT 的 Plugins 页面，从新增菜单选择上传 Plugin ZIP（具体按钮名称依客户端而定），选择 `school-research 1.02 ChatGPT Plugin.zip`。
2. 按界面完成扫描、安装或启用。若没有上传入口，检查工作区的 Upload plugins 权限；不要把 ZIP 作为普通聊天附件当作安装。
3. 新建 Work 对话，输入 `@`，选择 Plugins 下的 school-research 1.02。
4. 首次发送：使用 school-research，先实测官方网页读取和 Markdown 文件读写能力，只报告能力档位，不生成学校事实。
5. 能力确认后采集申请画像；研究具体学校前仍须明确确认其官方域名。

本包提供工作流程，不自带 MCP 服务，也不额外授予联网或文件权限。
当前仅完成打包与本地结构检查，尚未实际在 ChatGPT Work 安装或验证学校事实准确性。

## 包结构

- `plugin.json`：当前官方推荐的便携入口与 OpenAI 显示信息。
- `.codex-plugin/plugin.json`：兼容旧版入口；字段与主清单保持一致。
- `skills/school-research/`：SKILL.md、references/、templates/。

官方依据（2026-10-31 查阅）：
- https://developers.openai.com/plugins/build/plugins
- https://learn.chatgpt.com/docs/enterprise/apps-and-connectors
- https://learn.chatgpt.com/docs/build-plugins
